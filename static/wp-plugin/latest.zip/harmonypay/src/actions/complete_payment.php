<?php

namespace harmonypay\actions;

/**
	@brief		Mark a payment as completed.
	@since		2018-03-04 18:25:50
**/
class complete_payment
	extends payment_action
{
}
