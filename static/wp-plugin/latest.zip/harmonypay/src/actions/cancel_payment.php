<?php

namespace harmonypay\actions;

/**
	@brief		Mark a payment as cancelled.
	@since		2018-03-04 18:25:50
**/
class cancel_payment
	extends payment_action
{
}
