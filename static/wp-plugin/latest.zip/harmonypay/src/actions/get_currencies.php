<?php

namespace harmonypay\actions;

/**
	@brief		Fill the Currencies object with currencies.
	@since		2018-03-11 21:49:10
**/
class get_currencies
	extends action
{
	/**
		@brief		IN / OUT: The Currencies object to modify.
		@since		2018-03-11 21:49:20
	**/
	public $currencies;
}
