<?php

namespace harmonypay;

/**
	@brief		Convenience class so that we don't have to keep referring to the whole SDK path.
	@since		2017-12-09 07:27:47
**/
class Collection
	extends \plainview\sdk_mcc\collections\Collection
{
}
